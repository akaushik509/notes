sweet=["rasgulla","barfi"];
let res=sweet.forEach(function(el,i){
  return el;
})

console.log(res);

/*output= undefineed*/
/* No return forEach thats why out =undefined*/