function javascript("avi"){
  console.log("Avinash Kaushik"+" "+"How are you"+" "+message);
}
/* No output without calling this function*/

javascript(message);

/* Order of Execution - 6->1->2 */
/* Here my argument is "message" and paramenter is "avi" */