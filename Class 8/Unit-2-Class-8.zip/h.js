
/*desired output= [6,8]*/
let num=[3,6,8,1,9];

let res=num.filter(function(el){
  return (el%2==0);
})
console.log(res);

/* FOr each map annd filters havaeing same paramenters element index and array */

/*filter is returning elements where condition is true*/