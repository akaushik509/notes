let arr=["apple", "windows", "ubuntu"];
let a=arr.map(function(el){
  return arr[el].length;
})
console.log(a);