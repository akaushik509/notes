Chaining:- 
  Method------Input-----Output

  forEach     array     not an array (value)
  map         array     returns array
  filter      array     returns Array  
  reduce      array     single value


chaining means connecting output to the input of another things


forEach().map()-Not possible
forEach().filter()- Not possible
map().filter()- possible
map().reduce()- possible
filter().reduce()- possible
map().forEach()- Not Possible