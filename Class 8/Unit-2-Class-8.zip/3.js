/* we can assign let a = string/number/bolean/object/array */

/* Now we will assign function to a variable */
let abc=function(){   /* Here my function name is abc*/
  console.log("Avinash");
}

abc();

/* Output = Avinash */