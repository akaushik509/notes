
let arr=[2,4,6,8];
/* want my output= [4,8,12,16] */

/* By using map */


let mulby2=function(el){
  return (el*2);
}

let res=arr.map(Number);

let Number=function(el){
  return Number(el);
}

console.log(res);
lkasndgkljnkasjngajsknkfasdd