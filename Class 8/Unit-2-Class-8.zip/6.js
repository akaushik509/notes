function web19(count,web18){
  console.log("we are student of web 19 and we are",count,"in number");
  web18();
}

web19(700,web18);

function web18(){
  console.log("there are 130 web18 studetn as well")
}

/* order of execution 
1. 6
2. 1
3. 2
4. 3
5. 8 
6. 9 */
