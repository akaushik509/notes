let arrOfObj=[{name:"Avinash",place:"Patna"},
              {name:"Shalini",place:"Delhi"},
              {name:"Shilpa",place:"Canada"}];

arrOfObj.map(function(el){
  console.log(el.name);
})