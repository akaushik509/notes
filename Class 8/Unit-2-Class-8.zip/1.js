function javascript(){
  console.log("Avinash Kaushik");
}
/* No output without calling this function*/

javascript();

/* Order of Execution - 6->1->2 */