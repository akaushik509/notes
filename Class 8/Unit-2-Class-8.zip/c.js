

sweet=["rasgulla","barfi"];
let res=sweet.map(function(el,i){
  return el;
})

console.log(res);

/*function parameters are same for map and forEach*/